//
//  LoginFunctions.swift
//  recap
//
//  Created by Diptayan Jash on 15/12/24.
//

import FirebaseAuth
import FirebaseCore
import FirebaseFirestore
import GoogleSignIn
import UIKit

extension PatientLoginViewController {
    @objc func rememberMeTapped() {
        rememberMeButton.isSelected.toggle()
    }

    @objc func loginTapped() {
        print("Login tapped")

        guard let loginVC = self as? PatientLoginViewController else { return }

        let email = loginVC.emailField.text ?? ""
        let password = loginVC.passwordField.text ?? ""

        Auth.auth().signIn(withEmail: email, password: password) { [weak loginVC] authResult, error in
            if let error = error {
                print("Login failed: \(error.localizedDescription)")
                loginVC?.showAlert(message: "Invalid email or password.")
                return
            }

            guard let user = authResult?.user else { return }
            let userId = user.uid // Get the patient ID from Firebase session

            FirebaseManager.shared.fetchUserDetails(userId: userId) { userDetails, error in
                if let error = error {
                    print("Error fetching user details: \(error.localizedDescription)")
                    return
                }

                if let userDetails = userDetails {
                    UserDefaultsStorageProfile.shared.saveProfile(details: userDetails.dictionary, image: nil) { [weak loginVC] success in
                        if success {
                            // Fetch family members
                            FirebaseManager.shared.fetchFamilyMembers(for: userId) { familyMembers, error in
                                if let familyMembers = familyMembers {
                                    // Handle family members as needed
                                }
                            }
                            let mainVC = TabbarViewController()
                            loginVC?.navigationController?.setViewControllers([mainVC], animated: true)
                        } else {
                            print("Failed to save profile")
                        }
                    }
                } else {
                    print("User profile not found.")
                    loginVC?.showAlert(message: "User profile not found.")
                }
            }
        }
    }

    @objc func signupTapped() {
//        let signupVC = PatientSignupViewController()
//        navigationController?.pushViewController(signupVC, animated: true)

        let signupVC = patientInfo()
        let nav = UINavigationController(rootViewController: signupVC)
        present(nav, animated: true)
    }

    @objc func googleLoginTapped() {
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            print("Firebase client ID not found")
            return
        }

        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config

        GIDSignIn.sharedInstance.signIn(withPresenting: self) { [weak self] result, error in
            guard let self = self else { return }

            if let error = error {
                print("Google Sign-In Error: \(error.localizedDescription)")
                self.showAlert(message: "Google Sign-In failed. Please try again.")
                return
            }

            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString else {
                print("Failed to retrieve Google user")
                self.showAlert(message: "Unable to retrieve user information.")
                return
            }

            // Create Firebase credential
            let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                           accessToken: user.accessToken.tokenString)

            // Authenticate with Firebase
            Auth.auth().signIn(with: credential) { [weak self] authResult, authError in
                guard let self = self else { return }

                // Handle authentication error
                if let authError = authError {
                    print("Firebase Authentication Error: \(authError.localizedDescription)")
                    self.showAlert(message: "Authentication failed. Please try again.")
                    return
                }

                // Successfully authenticated
                guard let firebaseUser = authResult?.user else {
                    self.showAlert(message: "Login unsuccessful. Please try again.")
                    return
                }

                // Check if the user profile exists in Firestore
                let db = Firestore.firestore()
                let userId = firebaseUser.uid

                // Prepare user profile
                let userProfile: [String: Any] = [
                    "uid": firebaseUser.uid,
                    "firstName": firebaseUser.displayName ?? "",
                    "email": firebaseUser.email ?? "",
                    "profileImageURL": firebaseUser.photoURL?.absoluteString ?? "",
                    "hasCompletedProfile": false,
                ]

                // Save user profile to UserDefaults
                UserDefaultsStorageProfile.shared.saveProfile(details: userProfile, image: nil) { [weak self] _ in
                    guard let self = self else { return }

                    // Check if the user profile exists in Firestore
                    db.collection("users").document(userId).getDocument { document, error in
                        if let error = error {
                            print("Error fetching user profile: \(error.localizedDescription)")
                            self.showAlert(message: "Failed to fetch user profile.")
                            return
                        }

                        if let document = document, document.exists {
                            // User profile exists, navigate to main view controller
                            let mainVC = TabbarViewController()
                            self.navigationController?.setViewControllers([mainVC], animated: true)
                        } else {
                            // Navigate to patientInfo to create a profile
                            let patientInfoVC = patientInfo()
                            let nav = UINavigationController(rootViewController: patientInfoVC)
                            self.present(nav, animated: true)
                        }
                    }
                }
            }
        }
    }

    @objc func appleLoginTapped() {
        print("Apple login tapped")
        // Implement Apple login logic here
    }

    @objc func logoutTapped() {
        do {
            // Sign out from Firebase Authentication
            try Auth.auth().signOut()

            // Sign out from Google Sign-In
            GIDSignIn.sharedInstance.signOut()

            // Clear user session and local storage
            UserDefaults.standard.removeObject(forKey: "hasCompletedProfile")
            UserDefaultsStorageProfile.shared.clearProfile()

            // Animate the swipe down effect
            guard let window = UIApplication.shared.windows.first else { return }

            // Create the welcome view controller
            let welcomeVC = WelcomeViewController()
            let navigationController = UINavigationController(rootViewController: welcomeVC)

            // Set the initial position of the new view controller off-screen
            navigationController.view.frame = CGRect(x: 0, y: window.frame.height, width: window.frame.width, height: window.frame.height)
            window.rootViewController = navigationController
            window.makeKeyAndVisible()

            // Animate the transition
            UIView.animate(withDuration: 0.5, animations: {
                // Move the current view controller off-screen
                self.view.frame = CGRect(x: 0, y: window.frame.height, width: window.frame.width, height: window.frame.height)

                // Move the new view controller into view
                navigationController.view.frame = window.bounds
            }) { _ in
                // After the animation completes, set the root view controller to the new one
                window.rootViewController = navigationController
            }
        } catch {
            // Handle sign-out error
            print("Error signing out: \(error.localizedDescription)")
            showAlert(message: "Failed to log out. Please try again.")
        }
    }
}
