//
//  PrivacyViewController.swift
//  recap
//
//  Created by admin70 on 27/01/25.
//

import UIKit

class PrivacyViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Privacy"
    }
}
