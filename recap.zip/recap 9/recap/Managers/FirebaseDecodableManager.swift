//
//  FirebaseDecodableManager.swift
//  recap
//
//  Created by Diptayan Jash on 14/12/24.
//

import Foundation
protocol FireBaseDecodable {
    init(id: String,fireData: Any)
}
